const products = [
 {id:1,name:"Jellyfish Bag",price:500,category:"Bags",emoji:"👜",description:"A cute statement bag for your everyday essentials."},
 {id:2,name:"Vintage Hair Clip",price:50,category:"Accessories",emoji:"🎀",description:"A sweet handmade touch for your hairstyle."},
 {id:3,name:"Jellyfish Keychain",price:100,category:"Keychains",emoji:"🪼",description:"A tiny crochet buddy for your bag or keys."},
 {id:4,name:"Bandanas",price:250,category:"Wearables",emoji:"🧣",description:"A cozy, handmade accessory to style your look."},
 {id:5,name:"Tulips Head Band",price:150,category:"Wearables",emoji:"🌷",description:"A floral-inspired headband with a soft handmade feel."},
 {id:6,name:"Plushie Keychain",price:180,category:"Keychains",emoji:"🧸",description:"A tiny plush friend to take along anywhere."}
];
let cart = {};
const peso = n => "₱" + n.toLocaleString("en-PH");
const productsEl = document.getElementById("products");
function renderProducts(){
 const search = document.getElementById("searchInput").value.trim().toLowerCase();
 const category = document.getElementById("categoryFilter").value;
 const sort = document.getElementById("sortFilter").value;
 let shown = products.filter(p => (p.name.toLowerCase().includes(search) || p.description.toLowerCase().includes(search)) && (category==="All" || p.category===category));
 if(sort==="low") shown.sort((a,b)=>a.price-b.price);
 if(sort==="high") shown.sort((a,b)=>b.price-a.price);
 document.getElementById("productCount").textContent = `${shown.length} product${shown.length===1?"":"s"} found`;
 productsEl.innerHTML = shown.length ? shown.map(p=>`
 <article class="product-card">
   <div class="product-art" aria-label="${p.name} illustration">${p.emoji}</div>
   <div class="product-info"><h3>${p.name}</h3><p>${p.description}</p>
   <div class="price-row"><span class="price">${peso(p.price)}</span><span style="font-size:12px;color:#766a63">${p.category}</span></div>
   <button class="add-btn" data-add="${p.id}">＋ Add to cart</button></div>
 </article>`).join("") : '<div class="empty">No products found. Try another search.</div>';
}
function renderCart(){
 const entries = Object.entries(cart).filter(([id,qty])=>qty>0);
 const count = entries.reduce((sum,[id,qty])=>sum+qty,0);
 const total = entries.reduce((sum,[id,qty])=>sum+products.find(p=>p.id===Number(id)).price*qty,0);
 document.getElementById("cartCount").textContent=count;
 document.getElementById("cartTotal").textContent=peso(total);
 document.getElementById("cartItems").innerHTML = entries.length ? entries.map(([id,qty])=>{
  const p=products.find(item=>item.id===Number(id));
  return `<div class="cart-item"><div><div class="cart-item-name">${p.emoji} ${p.name}</div><div>${peso(p.price)} each · ${peso(p.price*qty)}</div></div><div class="cart-controls"><button class="qty-btn" data-change="${id}" data-delta="-1" aria-label="Decrease ${p.name} quantity">−</button><strong>${qty}</strong><button class="qty-btn" data-change="${id}" data-delta="1" aria-label="Increase ${p.name} quantity">＋</button><button class="remove-btn" data-remove="${id}">Remove</button></div></div>`;
 }).join("") : '<p>Your cart is empty. Add something cute from the collection!</p>';
 if(!entries.length){document.getElementById("checkoutForm").classList.remove("open");document.getElementById("checkoutMessage").textContent="";}
}
function toggleCart(show){document.getElementById("cartPanel").classList.toggle("open",show);if(show)document.getElementById("cartPanel").scrollIntoView({behavior:"smooth",block:"start"});}
productsEl.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const id=b.dataset.add;cart[id]=(cart[id]||0)+1;renderCart();b.textContent="✓ Added!";setTimeout(()=>{if(b.isConnected)b.textContent="＋ Add to cart"},900);});
document.getElementById("cartItems").addEventListener("click",e=>{
 const change=e.target.closest("[data-change]"),remove=e.target.closest("[data-remove]");
 if(change){const id=change.dataset.change;cart[id]=(cart[id]||0)+Number(change.dataset.delta);if(cart[id]<=0)delete cart[id];}
 if(remove)delete cart[remove.dataset.remove];
 renderCart();
});
["searchInput","categoryFilter","sortFilter"].forEach(id=>document.getElementById(id).addEventListener(id==="searchInput"?"input":"change",renderProducts));
document.getElementById("cartToggle").addEventListener("click",()=>toggleCart(!document.getElementById("cartPanel").classList.contains("open")));
document.getElementById("shopNav").addEventListener("click",()=>document.getElementById("shop").scrollIntoView({behavior:"smooth"}));
document.getElementById("shopNow").addEventListener("click",()=>document.getElementById("shop").scrollIntoView({behavior:"smooth"}));
document.getElementById("aboutNav").addEventListener("click",()=>document.getElementById("about").scrollIntoView({behavior:"smooth"}));
document.getElementById("clearCart").addEventListener("click",()=>{cart={};renderCart();});
document.getElementById("checkoutBtn").addEventListener("click",()=>{
 if(!Object.keys(cart).length){document.getElementById("checkoutMessage").textContent="Your cart is empty. Add a product before checkout.";return;}
 document.getElementById("checkoutForm").classList.toggle("open");
});
document.getElementById("checkoutForm").addEventListener("submit",e=>{
 e.preventDefault();
 const entries=Object.entries(cart).filter(([id,qty])=>qty>0);
 if(!entries.length)return;
 const lines=entries.map(([id,qty])=>{const p=products.find(item=>item.id===Number(id));return `${p.name} x ${qty} = ${peso(p.price*qty)}`;});
 const total=entries.reduce((sum,[id,qty])=>sum+products.find(p=>p.id===Number(id)).price*qty,0);
 document.getElementById("checkoutMessage").textContent=`Thanks, ${document.getElementById("customerName").value}! Demo order prepared for ${peso(total)}. This is a sample website, so no order or payment was sent.`;
 document.getElementById("checkoutForm").classList.remove("open");
});
renderProducts();renderCart();
